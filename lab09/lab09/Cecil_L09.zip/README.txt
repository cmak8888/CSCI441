Q1: A uniform variable is basically a global global variable that is uniformly available in each GLSL file.
MVPmatrix is a modelviewprojection matrix that should be consistent throughout the files.
Q2: Attributes are unique to each vertex. Each vertex will have a unique Position.
Q3: A varying variables is data passed from the vertex shader to the fragment shader. The color of the vertex should be set after the fragments have been assembled.
Q4: The only thing we are changed is the input/outputs of our code rather than the code itself. So we can simply rerun the code.
Q5: The sphere looks like this because the coloring option per fragment and setting each fragment to the same color.
Q6: No, each functionality in correlation to the pipeline is still confusing.
Q7: 2
Q8: Parts of it were good, some parts were too vague.
Q9: 4 hours.
Q10: None.