CSCI441, Computer Graphics, Fall 2019
Calvin Mak
Q1: It is now bricked.
Q2: Every object is textured like a brick.
Q3: It looked pretty dark and one-sided.
Q4: Yes
Q5: Yes, it is oriented sideways.
Q6: Now I have 4 logos.
Q7: The lab was a 7.
Q8: I liked the first part, it got a little confusing on how some of the textures questions functions so I was lost for a few days on question 5.
Q9: 3 days.
Q10: Nada.