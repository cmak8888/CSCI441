CSCI441, Computer Graphics, Fall 2019
Calvin Mak

Code Example: Lab08

Q1: 6 Fun-ish
Q2: It was a little vague on which data we should be passing where.
Q3: 4 hours.
Q4: None.