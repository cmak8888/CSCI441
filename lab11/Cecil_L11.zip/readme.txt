Q1: The marbles moves straight and flat, forever.
Q2: Yes. <-1,0,0>, <1,0,0>, <0,0,-1> and <0,0,1>.
Q3: N1= L1 - L2. N2 = L2 - L1. Normalize the distance between 2 points to get the vector normal to the collision plane.
Q4: Yes.
Q5: 8 .
Q6: Just Right.
Q7: 2 hours.
Q8: None.