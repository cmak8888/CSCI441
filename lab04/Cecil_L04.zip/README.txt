Q1: 6
Q2: There were lots of ambiguous bits and was too vague.
Q3: This lab tok me at least 2 hours.
Q4: I had trouble with figuring out the lighting of my emerald floor, despite setting the normalized vector of each point.
