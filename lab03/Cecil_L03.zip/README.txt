CSCI441, Computer Graphics, Fall 2019
Calvin Mak
Q1: 7
Q2: It was almost just right, it was a bit vague on the application of the bezier curve equation.
Q3: This took me about 7 hours.
Q4: None