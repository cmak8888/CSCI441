 Q1: I was kinda able to navigate between 2 buildings.
 Q2: The lab was difficult and confusing to understand. So I give it a 3.
 Q3: The lab was too vague.
 Q4: The lab took me 2 and a half hours.
 Q5: None.